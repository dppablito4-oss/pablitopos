Este archivo es un respaldo señuelo. Los datos reales se guardan en el perfil del usuario (APPDATA).
